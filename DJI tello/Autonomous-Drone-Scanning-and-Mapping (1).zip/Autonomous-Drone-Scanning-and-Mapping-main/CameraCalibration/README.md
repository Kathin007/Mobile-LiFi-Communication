# Opencv Camera Calibration
Calibrate camera using chessboard image - used for dji tello.
